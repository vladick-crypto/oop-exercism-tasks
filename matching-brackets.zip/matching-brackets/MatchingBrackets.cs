using System;
using System.Collections.Generic;

public static class MatchingBrackets
{
    public static bool IsPaired(string input)
    {
        var stack = new Stack<char>();
        var pairs = new Dictionary<char, char>
        {
            { ']', '[' },
            { '}', '{' },
            { ')', '(' }
        };

        foreach (char c in input)
        {
            // Якщо дужка відкривається — кладемо в стек
            if (c == '[' || c == '{' || c == '(')
            {
                stack.Push(c);
            }
            // Якщо закривається — перевіряємо, чи є для неї пара
            else if (pairs.ContainsKey(c))
            {
                if (stack.Count == 0 || stack.Pop() != pairs[c])
                {
                    return false;
                }
            }
        }
        
        // Якщо стек порожній, значить всі дужки закрилися правильно
        return stack.Count == 0;
    }
}