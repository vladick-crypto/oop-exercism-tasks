using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public static class Tournament
{
    public static void Tally(Stream inStream, Stream outStream)
    {
        var teams = new Dictionary<string, TeamStats>();
        
        using (var reader = new StreamReader(inStream))
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                if (string.IsNullOrWhiteSpace(line)) continue;
                
                var parts = line.Split(';');
                if (parts.Length != 3) continue;

                string t1 = parts[0];
                string t2 = parts[1];
                string result = parts[2];

                if (!teams.ContainsKey(t1)) teams[t1] = new TeamStats(t1);
                if (!teams.ContainsKey(t2)) teams[t2] = new TeamStats(t2);

                if (result == "win") { teams[t1].AddWin(); teams[t2].AddLoss(); }
                else if (result == "loss") { teams[t1].AddLoss(); teams[t2].AddWin(); }
                else if (result == "draw") { teams[t1].AddDraw(); teams[t2].AddDraw(); }
            }
        }

        var sortedTeams = teams.Values
            .OrderByDescending(t => t.Points)
            .ThenBy(t => t.Name);

        using (var writer = new StreamWriter(outStream))
        {
            writer.Write("Team                           | MP |  W |  D |  L |  P");
            foreach (var t in sortedTeams)
            {
                writer.Write($"\n{t.Name,-30} | {t.MatchesPlayed,2} | {t.Wins,2} | {t.Draws,2} | {t.Losses,2} | {t.Points,2}");
            }
        }
    }

    class TeamStats
    {
        public string Name { get; }
        public int Wins { get; private set; }
        public int Draws { get; private set; }
        public int Losses { get; private set; }
        public int MatchesPlayed => Wins + Draws + Losses;
        public int Points => (Wins * 3) + (Draws * 1);

        public TeamStats(string name)
        {
            Name = name;
        }

        public void AddWin() => Wins++;
        public void AddDraw() => Draws++;
        public void AddLoss() => Losses++;
    }
}