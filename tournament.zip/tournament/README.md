# Турнір

Вітаємо у вправі Турнір на треку C# від Exercism.
Якщо потрібна допомога із запуском тестів або надсиланням коду, перегляньте `HELP.md`.

## Instructions

Підрахуйте результати невеликого футбольного змагання.

На основі вхідного файлу, який містить інформацію про те, яка команда з якою грала і яким був результат, створіть файл із таблицею такого вигляду:

```text
Team                           | MP |  W |  D |  L |  P
Devastating Donkeys            |  3 |  2 |  1 |  0 |  7
Allegoric Alaskans             |  3 |  2 |  0 |  1 |  6
Blithering Badgers             |  3 |  1 |  0 |  2 |  3
Courageous Californians        |  3 |  0 |  1 |  2 |  1
```

Що означають ці скорочення?

- MP: зіграні матчі
- W: перемоги
- D: нічиї (зрівняний рахунок)
- L: поразки
- P: очки

За перемогу команда отримує 3 очки.
За нічию отримує 1.
За поразку отримує 0.

Результати впорядковано за очками у спадному порядку.
У разі рівності очок команди впорядковуються за алфавітом.

## Вхідні дані

Програма для підрахунку отримає вхідні дані такого вигляду:

```text
Allegoric Alaskans;Blithering Badgers;win
Devastating Donkeys;Courageous Californians;draw
Devastating Donkeys;Allegoric Alaskans;win
Courageous Californians;Blithering Badgers;loss
Blithering Badgers;Devastating Donkeys;loss
Allegoric Alaskans;Courageous Californians;win
```

Результат матчу стосується першої команди, зазначеної в рядку.
Отже, цей рядок:

```text
Allegoric Alaskans;Blithering Badgers;win
```

означає, що Allegoric Alaskans перемогли Blithering Badgers.

Цей рядок:

```text
Courageous Californians;Blithering Badgers;loss
```

означає, що Blithering Badgers перемогли Courageous Californians.

А цей рядок:

```text
Devastating Donkeys;Courageous Californians;draw
```

означає, що Devastating Donkeys і Courageous Californians зіграли внічию.

## Source

### Created by

- @pminten

### Contributed to by

- @bressain
- @ErikSchierboom
- @GKotfis
- @j2jensen
- @jwood803
- @robkeim
- @wolf99