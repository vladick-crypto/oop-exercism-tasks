using System;

public class BankAccount
{
    private decimal _balance;
    private bool _isOpen;
    private readonly object _lockObj = new object();

    public void Open()
    {
        if (_isOpen) throw new InvalidOperationException("Cannot open an already opened account");
        _isOpen = true;
        _balance = 0;
    }

    public void Close()
    {
        if (!_isOpen) throw new InvalidOperationException("Cannot close an account that was not opened");
        _isOpen = false;
    }

    public decimal Balance
    {
        get
        {
            if (!_isOpen) throw new InvalidOperationException("Account is closed");
            return _balance;
        }
    }

    public void Deposit(decimal amount)
    {
        lock (_lockObj)
        {
            if (!_isOpen) throw new InvalidOperationException("Account is closed");
            if (amount < 0) throw new InvalidOperationException("Amount must be positive");
            
            _balance += amount;
        }
    }

    public void Withdraw(decimal amount)
    {
        lock (_lockObj)
        {
            if (!_isOpen) throw new InvalidOperationException("Account is closed");
            if (amount < 0) throw new InvalidOperationException("Amount must be positive");
            if (amount > _balance) throw new InvalidOperationException("Insufficient funds");
            
            _balance -= amount;
        }
    }
}