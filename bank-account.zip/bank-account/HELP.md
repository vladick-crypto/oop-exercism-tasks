# Help

## Запуск тестів

Тести можна запустити, відкривши командний рядок у каталозі вправи, а потім виконавши [команду `dotnet test`](https://docs.microsoft.com/en-us/dotnet/core/tools/dotnet-test).
Крім того, більшість середовищ розробки (IDE) мають вбудовану підтримку запуску тестів, зокрема [Visual Studio](https://docs.microsoft.com/en-us/visualstudio/test/run-unit-tests-with-test-explorer), [Rider](https://www.jetbrains.com/help/rider/Unit_Testing_in_Solution.html) і [Visual Studio code](https://github.com/OmniSharp/omnisharp-vscode/wiki/How-to-run-and-debug-unit-tests).
Більше інформації можна знайти на [сторінці з тестами](https://exercism.org/docs/tracks/csharp/tests).

## Пропущені тести

Спочатку буде увімкнено лише перший тест.
Це зроблено, щоб заохотити розвʼязувати вправу крок за кроком.
Щойно перший тест почне проходити, видаліть властивість `Skip` з наступного тесту і попрацюйте над тим, щоб він теж проходив.

## Надсилання рішення

Рішення можна надіслати за допомогою команди `exercism submit BankAccount.cs`.
Ця команда завантажить рішення на сайт Exercism і надрукує URL сторінки рішення.

Можна надіслати й незавершене рішення, що дає змогу:

- Побачити, як вправу розвʼязали інші
- Попросити допомоги в наставника

## Потрібна допомога?

Якщо потрібна допомога з розвʼязанням вправи, перегляньте такі сторінки:

- [Документація треку C#](https://exercism.org/docs/tracks/csharp)
- [Категорія програмування треку C# на форумі](https://forum.exercism.org/c/programming/csharp)
- [Категорія програмування Exercism на форумі](https://forum.exercism.org/c/programming/5)
- [Поширені запитання](https://exercism.org/docs/using/faqs)

Якщо цих ресурсів не вистачить, можна надіслати (незавершене) рішення, щоб попросити наставництва.

Якщо виникли труднощі, можна скористатися одним із таких ресурсів:

- [/r/csharp](https://www.reddit.com/r/csharp) - це субредіт C#.
- [StackOverflow](http://stackoverflow.com/questions/tagged/c%23) можна використати, щоб пошукати свою проблему й подивитися, чи на неї вже відповіли. Там також можна ставити запитання й відповідати на них.