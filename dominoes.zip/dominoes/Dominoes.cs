using System;
using System.Collections.Generic;
using System.Linq;

public static class Dominoes
{
    public static bool CanChain(IEnumerable<(int, int)> dominoes)
    {
        var list = dominoes.ToList();
        if (list.Count == 0) return true;
        
        return TryChain(list, new List<(int, int)>(), new bool[list.Count]);
    }

    private static bool TryChain(List<(int, int)> dominoes, List<(int, int)> chain, bool[] used)
    {
        if (chain.Count == dominoes.Count)
        {
            return chain.First().Item1 == chain.Last().Item2;
        }

        for (int i = 0; i < dominoes.Count; i++)
        {
            if (used[i]) continue;

            var d = dominoes[i];
            if (chain.Count == 0)
            {
                used[i] = true;
                chain.Add(d);
                if (TryChain(dominoes, chain, used)) return true;
                chain.RemoveAt(chain.Count - 1);
                used[i] = false;
            }
            else
            {
                var last = chain.Last().Item2;
                if (d.Item1 == last)
                {
                    used[i] = true;
                    chain.Add(d);
                    if (TryChain(dominoes, chain, used)) return true;
                    chain.RemoveAt(chain.Count - 1);
                    used[i] = false;
                }
                else if (d.Item2 == last)
                {
                    used[i] = true;
                    chain.Add((d.Item2, d.Item1));
                    if (TryChain(dominoes, chain, used)) return true;
                    chain.RemoveAt(chain.Count - 1);
                    used[i] = false;
                }
            }
        }
        return false;
    }
}