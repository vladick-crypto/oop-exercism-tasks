# Bob

Вітаємо у вправі Bob на треку C# від Exercism.
Якщо потрібна допомога із запуском тестів або надсиланням коду, перегляньте `HELP.md`.

## Introduction

Боб - [безтурботний][lackadaisical] підліток.
Він любить вважати себе дуже крутим.
І він точно не захоплюється різними речами.
Це було б не круто.

Коли люди з ним розмовляють, його відповіді досить обмежені.

[lackadaisical]: https://www.collinsdictionary.com/dictionary/english/lackadaisical

## Instructions

Визначте, що Боб відповість, коли йому щось кажуть або запитують його.

Боб завжди відповідає одним із пʼяти:

- **"Sure."**
  Це його відповідь, якщо ми запитуємо його, наприклад, «How are you?»
  Заведено, що запитання закінчується знаком питання.
- **"Whoa, chill out!"**
  Це його відповідь, якщо ми КРИЧИМО НА НЬОГО.
  Заведено, що крик передають усіма великими літерами.
- **"Calm down, I know what I'm doing!"**
  Це те, що він каже, якщо ми кричимо йому запитання.
- **"Fine. Be that way!"**
  Так він відповідає на тишу.
  Заведено, що тиша - це нічого або різні комбінації пробільних символів.
- **"Whatever."**
  Це його відповідь на все інше.

## Source

### Contributed to by

- @austinlyons
- @bressain
- @delve
- @ErikSchierboom
- @j2jensen
- @jwood803
- @kytrinyx
- @robkeim
- @tomschluter
- @wolf99

### Based on

Inspired by the 'Deaf Grandma' exercise in Chris Pine's Learn to Program tutorial. - https://pine.fm/LearnToProgram/chap_06.html