using System;

public static class Bob
{
    public static string Response(string statement)
    {
        var text = statement.Trim();
        if (string.IsNullOrWhiteSpace(text)) return "Fine. Be that way!";
        
        bool isYell = text.ToUpper() == text && text.ToLower() != text && System.Text.RegularExpressions.Regex.IsMatch(text, "[A-Za-z]");
        bool isQuestion = text.EndsWith("?");

        if (isYell && isQuestion) return "Calm down, I know what I'm doing!";
        if (isYell) return "Whoa, chill out!";
        if (isQuestion) return "Sure.";
        
        return "Whatever.";
    }
}