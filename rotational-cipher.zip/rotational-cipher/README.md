# Обертальний шифр

Вітаємо у вправі Обертальний шифр на треку C# від Exercism.
Якщо потрібна допомога із запуском тестів або надсиланням коду, перегляньте `HELP.md`.

## Instructions

Створіть реалізацію шифру обертання, який іноді ще називають шифром Цезаря.

Шифр Цезаря - це простий шифр зсуву, який ґрунтується на перестановці всіх літер алфавіту за допомогою ключа у вигляді цілого числа від `0` до `26`.
Використання ключа `0` або `26` завжди дає той самий результат через модульну арифметику.
Літера зсувається на стільки значень, скільки дорівнює значення ключа.

Загальне позначення для шифрів обертання - `ROT + <key>`.
Найпоширеніший шифр обертання - `ROT13`.

`ROT13` для латинського алфавіту має такий вигляд:

```text
Plain:  abcdefghijklmnopqrstuvwxyz
Cipher: nopqrstuvwxyzabcdefghijklm
```

Він сильніший за шифр Атбаш, бо має 27 можливих ключів і 25 придатних до використання ключів.

Шифротекст записують у тому самому форматі, що й вхідні дані, разом із пробілами та розділовими знаками.

## Приклади

- ROT5 `omg` дає `trl`
- ROT0 `c` дає `c`
- ROT26 `Cool` дає `Cool`
- ROT13 `The quick brown fox jumps over the lazy dog.` дає `Gur dhvpx oebja sbk whzcf bire gur ynml qbt.`
- ROT13 `Gur dhvpx oebja sbk whzcf bire gur ynml qbt.` дає `The quick brown fox jumps over the lazy dog.`

## Source

### Created by

- @ErikSchierboom

### Contributed to by

- @j2jensen
- @robkeim
- @wolf99

### Based on

Wikipedia - https://en.wikipedia.org/wiki/Caesar_cipher