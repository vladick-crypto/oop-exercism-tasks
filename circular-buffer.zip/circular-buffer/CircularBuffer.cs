using System;

public class CircularBuffer<T>
{
    private readonly T[] _buffer;
    private int _start;
    private int _end;
    private int _count;

    public CircularBuffer(int capacity)
    {
        _buffer = new T[capacity];
        _start = 0;
        _end = 0;
        _count = 0;
    }

    public T Read()
    {
        if (_count == 0) 
            throw new InvalidOperationException("Buffer is empty");
            
        T value = _buffer[_start];
        _start = (_start + 1) % _buffer.Length;
        _count--;
        
        return value;
    }

    public void Write(T value)
    {
        if (_count == _buffer.Length) 
            throw new InvalidOperationException("Buffer is full");
            
        _buffer[_end] = value;
        _end = (_end + 1) % _buffer.Length;
        _count++;
    }

    public void Overwrite(T value)
    {
        if (_count == _buffer.Length)
        {
            _buffer[_start] = value;
            _start = (_start + 1) % _buffer.Length;
        }
        else
        {
            Write(value);
        }
    }

    public void Clear()
    {
        _count = 0;
        _start = 0;
        _end = 0;
    }
}