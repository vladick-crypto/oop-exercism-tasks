using System;

public static class PigLatin
{
    public static string Translate(string text)
    {
        // 23-й тест передає ціле речення. Тому ми розрізаємо текст на окремі слова по пробілу.
        string[] words = text.Split(' ');
        string[] translatedWords = new string[words.Length];

        for (int w = 0; w < words.Length; w++)
        {
            string word = words[w];
            
            // Правило 1: Починається з голосної, "xr" або "yt"
            if (word.StartsWith("a") || word.StartsWith("e") || word.StartsWith("i") || 
                word.StartsWith("o") || word.StartsWith("u") || 
                word.StartsWith("xr") || word.StartsWith("yt"))
            {
                translatedWords[w] = word + "ay";
                continue; // Записали і переходимо до наступного слова
            }

            // Правила 2, 3, 4: Шукаємо місце для розрізу
            int cutIndex = 0;
            for (int i = 0; i < word.Length; i++)
            {
                char c = word[i];
                
                // Якщо знайшли звичайну голосну
                if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
                {
                    // Пастка з "qu" (Правило 3)
                    if (c == 'u' && i > 0 && word[i - 1] == 'q')
                    {
                        cutIndex = i + 1; // Ріжемо ПІСЛЯ 'u'
                    }
                    else
                    {
                        cutIndex = i; // Звичайний розріз
                    }
                    break; // Знайшли розріз — виходимо з циклу
                }
                
                // Пастка з 'y' (Правило 4: 'y' вважається голосною, якщо перед нею є приголосні)
                if (c == 'y' && i > 0)
                {
                    cutIndex = i;
                    break;
                }
            }

            // Відрізаємо, міняємо місцями і додаємо "ay"
            translatedWords[w] = word.Substring(cutIndex) + word.Substring(0, cutIndex) + "ay";
        }

        // Зліплюємо всі перекладені слова назад у речення через пробіл
        return string.Join(" ", translatedWords);
    }
}