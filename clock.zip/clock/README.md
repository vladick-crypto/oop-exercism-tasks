# Годинник

Вітаємо у вправі Годинник на треку C# від Exercism.
Якщо потрібна допомога із запуском тестів або надсиланням коду, перегляньте `HELP.md`.

## Instructions

Реалізуйте годинник, який працює з часом без дат.

Потрібно вміти додавати хвилини до годинника й віднімати їх від нього.

Два годинники, які показують той самий час, мають бути рівними один одному.

## Підказки

У цій вправі потрібно реалізувати метод, визначений для конкретного типу, який визначає рівність примірників.
Докладніше дивіться на [цій сторінці](https://docs.microsoft.com/en-us/dotnet/api/System.IEquatable-1)

## Source

### Created by

- @rprouse

### Contributed to by

- @avjgit
- @bmeverett
- @bressain
- @ErikSchierboom
- @j2jensen
- @jwood803
- @kytrinyx
- @mattcbaker
- @robkeim
- @Thorocaine
- @vamcs
- @vgrigoriu
- @wolf99

### Based on

Pairing session with Erin Drummond