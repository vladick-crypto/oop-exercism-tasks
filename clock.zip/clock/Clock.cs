using System;

public class Clock
{
    private readonly int _minutes;
    private const int MinutesInDay = 24 * 60;

    public Clock(int hours, int minutes)
    {
        int total = (hours * 60 + minutes) % MinutesInDay;
        _minutes = total < 0 ? total + MinutesInDay : total;
    }

    public Clock Add(int minutesToAdd) => new Clock(0, _minutes + minutesToAdd);

    public Clock Subtract(int minutesToSubtract) => new Clock(0, _minutes - minutesToSubtract);

    public override string ToString() => $"{_minutes / 60:D2}:{_minutes % 60:D2}";

    public override bool Equals(object obj) => obj is Clock other && _minutes == other._minutes;

    public override int GetHashCode() => _minutes.GetHashCode();
}